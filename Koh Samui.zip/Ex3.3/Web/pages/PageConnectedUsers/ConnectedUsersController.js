angular.module("myApp")

.controller("ConnectedUsersController", function ($window,$rootScope,$scope,$http) {
   
    $scope.star=[];
    for(var i=0;i<4;i++){
    $scope.star.push("https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png")
    
}
    
    $scope.POI1="";
    $scope.POI2="";
    $scope.POI3="";
    $scope.POI4="";

    $scope.refresh = function() {
        self = this;
    $http.get('http://127.0.0.1:3000/users/getPopularPOIByInterests',{ headers:{'x-auth-token': $rootScope.token}})
    .then(function(response){
        if(response.data.length==1){
            $scope.POI1=response.data[0];
            loadImage(response.data[0],response.data[0]);
            var img2 = document.getElementById("POI2");
            img2.style.visibility = 'hidden';
    

        }
else{
        $scope.POI1=response.data[0];
        $scope.POI2=response.data[1];
        loadImage(response.data[0],response.data[1]);
    }

    })  
    .catch(function (err) {
        $scope.POI1=err;

    });


    $http.get('http://127.0.0.1:3000/users/getAllSavedFavoritePOI',{ headers:{'x-auth-token': $rootScope.token}})
    .then(function(response){

        if(response.data.length>=2){
        $scope.POI3=response.data[0];
        $scope.POI4=response.data[1];
        loadImage2(response.data[0],response.data[1]);
    }

    if(response.data.length==1){
        $scope.POI3=response.data[0];
        $scope.POI4=response.data[0];

        loadImage2(response.data[0],response.data[0]);
        var img2 = document.getElementById("POI4");
        img2.style.visibility = 'hidden';

    }

    })  
    .catch(function (err) {
        $scope.error=err.data.err;
        var img1 = document.getElementById("POI3");
        img1.style.visibility = 'hidden';


        var img2 = document.getElementById("POI4");
        img2.style.visibility = 'hidden';



    });   
    };


function loadImage(p1,p2){

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p1)
    .then(function(response){
        $scope.ImgPOI1=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI1=err;

    });

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p2)
    .then(function(response){
        $scope.ImgPOI2=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI2=err;

    });


}


function loadImage2(p1,p2){

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p1)
    .then(function(response){
        $scope.ImgPOI3=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI3=err;

    });

    $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p2)
    .then(function(response){
        $scope.ImgPOI4=response.data.Link;
    })  
    .catch(function (err) {
        $scope.ImgPOI4=err;

    });


}

$scope.opendetailes=function(POI1){

    $window.sessionStorage.setItem(1,POI1);   
    $window.open
   ('/index.html#!/POIDetailes', 
   'C-Sharpcorner', 
   'toolbar=no,scrollbars=no,resizable=no,top=100,left=500,width=600,height=400');

}
$scope.addfav=function(POI1,index){
        
    if($rootScope.token==""){
        alert("You must to Login In order to add to favorite");
        return;
    }

    if($scope.star[index]=="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png"){
        
    $rootScope.removefavorite(POI1);
    $scope.star[index]="https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png";
    }


    else{
        $rootScope.addtofavorite(POI1);
        $scope.star[index]="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png";
    }

}


});