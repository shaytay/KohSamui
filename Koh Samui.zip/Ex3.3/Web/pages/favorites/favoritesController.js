angular.module("myApp")

.controller("favoritesController", function ($window,$rootScope,$scope,$http) {
    $scope.Images=[];
    $scope.record=[];
    $scope.star=[];
    $scope.ranks=[];
    $scope.r="rank";
    $scope.c="catagory";

    $scope.sort=function (sortby){
       console.log(sortby);
       $scope.ranks=[];

       proms=[];
        for(var i=0;i<$scope.record.length;i++){
           proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.record[i]))
        }
           Promise.all(proms).then(function(response){ 

           for(var i=0;i<response.length;i++){
             
               const poi_rank={
               POIname:$scope.record[i],
               POIRank:response[i].data.POIRank,
               POICatagory:response[i].data.catagory
               };    
           $scope.ranks.push(poi_rank);
           }

           $scope.ranks.sort(function(a,b){
               if(sortby=="rank"){
            return a.POIRank - b.POIRank;
        }
        else{
            return a.POICatagory.toLowerCase().localeCompare(b.POICatagory.toLowerCase());
 
        }
            }
        );

            var sortedpoi=[];
            for(var k=0;k<$scope.record.length;k++){
                sortedpoi[k]=$scope.ranks[k].POIname;
            }
            console.log(sortedpoi);

            for(var i=0;i<sortedpoi.length;i++){
                loadImage(i,sortedpoi[i]);
                $scope.record[i]=sortedpoi[i];

            }

       })
           

      
       
       .catch(function(err){
           $scope.error=err.data.err;
       })


       }

    
    $scope.refresh = function() {
        self = this;
    $http.get('http://127.0.0.1:3000/users/getAllSavedFavoritePOI',{ headers:{'x-auth-token': $rootScope.token}})
    .then(function(response){

    for(var i=0; i<response.data.length; i++){
        loadImage(i,response.data[i]);
        
    }

    })  
    .catch(function (err) {
        $scope.POI=err.data.err;

    });
    }


    function loadImage(i,p1){
        $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+p1)
        .then(function(response){
            $scope.Images[i]=response.data.Link;
            $scope.record[i]=(p1);
            $scope.star[i]="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png";
        })  


        .catch(function (err) {
            //$scope.ImgPOI=err.data.err;
    
        });
    }


    $scope.opendetailes=function(POI1){
        $window.sessionStorage.setItem(1,POI1);   
        $window.open
       ('/index.html#!/POIDetailes', 
       'C-Sharpcorner', 
       'toolbar=no,scrollbars=no,resizable=no,top=100,left=500,width=600,height=400');
   
   }

   
   $scope.addfav=function(POI1,index){
    if($rootScope.token==""){
        alert("You must to Login In order to add to favorite");
        return;
    }

    if($scope.star[index]=="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png"){
        
    $rootScope.removefavorite(POI1);
    $scope.star[index]="https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png";
    }


    else{
        $rootScope.addtofavorite(POI1);
        $scope.star[index]="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png";
    }

}




});
