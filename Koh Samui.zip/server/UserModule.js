
const express = require("express");
const app = express();
var DButilsAzure = require('./DButils');
const jwt = require("jsonwebtoken");
app.use(express.json());
secret = "kofkofkofi";
const router=express.Router();
module.exports = router;

router.post('/Login/JsonLogin',(req, res) => {
    var username = req.body.username;
    var password = req.body.password;

    DButilsAzure.execQuery(`select * FROM users Where username= '` + username + `' And password='` + password + `' `)

        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "Login Failed,Username or password inccorrect" });
            }
            else {
                payload = { username: result[0].username };
                options = { expiresIn: "1d" };
                const token = jwt.sign(payload, secret, options);
                res.send(token);
            }

        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username " });
        });




});

function onlyLetters(str) {
    return str.match("^[A-z]+$");
}

router.post('/Registration/JsonRegister',(req, res,next) => {
    DButilsAzure.execQuery(`SELECT * FROM users Where username= '` + req.body.username + `'`)
        .then(function (result) {
            if(result==""){
                next()
            }
            else{
                res.status(400).send({ err: "The username already exists " });
            }
        })

        .catch(function (err) {
            res.status(400).send({ err: "Error " });
        });

});
router.post('/Registration/JsonRegister',(req, res,next )=> {

    var name = req.body.username;
    var pass = req.body.password;
    if (name.length < 3 || name.length > 8 || !onlyLetters(name)) {
        res.status(400).send({ err: "The Username must be only character and 3-8 length" });
        return;
    }
    if (pass.length < 5 || pass.length > 10) {
        res.status(400).send({ err: "password must be 5-10 characters" });
        return;
    }

    var interests = req.body.Interests;

    for(var i =0;i<interests.length;i++){
        if(interests[i]!="Shopping" &&interests[i]!="food" &&interests[i]!="attractions" &&interests[i]!="night clubs"){
            res.status(400).send({ err: "interests must be Shopping,food,attractions,night clubs" });
            return;
        }
    }

    var country = req.body.Country;
    DButilsAzure.execQuery(`SELECT * FROM Countries`)
        .then(function (result) {

            for (var i = 0; i < result.length; i++) {
                if (result[i].country == country) {
                    next();
                    return;
                }
                if (i == result.length - 1) {
                    res.status(400).send({ err: "country is not find in the list" });

                }
            }
        })

        .catch(function (err) {
            res.status(400).send({ err: "Error " });
        });


});
router.post('/Registration/JsonRegister',(req, res,next)=> {



    DButilsAzure.execQuery("insert into users(username, password,FirstName,LastName,City,Country,Email) values('" + req.body.username + "','" + req.body.password + "','" + req.body.FirstName + "','" +
        req.body.LastName + "','" + req.body.City + "','" + req.body.Country + "','" + req.body.Email+ "')")
        .then(function (result) {
            next();
            return;

        })

        .catch(function (err) {
            res.status(400).send({ err: "There is a problem insert to db maybe username already exist" });
            return;
        });





});
router.post('/Registration/JsonRegister',(req, res,next) => {

    DButilsAzure.execQuery("insert into Questions(username, question1,answer1,question2,answer2) values('" + req.body.username + "','" + req.body.question1 + "','" + req.body.answer1 + "','" +
        req.body.question2 + "','" + req.body.answer2 + "')")
        .then(function (result) {
            next();
            return;
        })

        .catch(function (err) {
            res.status(400).send({ err: "There is a problem with insert user to db" });
        });




});
router.post('/Registration/JsonRegister',(req, res,next )=> {

    for (var i = 0; i < req.body.Interests.length; i++) {

        DButilsAzure.execQuery("insert into interests(username, interest) values('" + req.body.username + "','" + req.body.Interests[i]+ "')")
            .then(function (result) {
                payload = { name: req.body.username };
                options = { expiresIn: "1d" };
                const token = jwt.sign(payload, secret, options);
                res.send(token);

            })

            .catch(function (err) {
                //res.status(400).send({ err: "There is a problem with insert user to db" });
            });


    }



});


var isverified = false;
router.post('/restorePassword',( req, res,next) => {

    var name = req.body.username;
    var ans1 = req.body.answer1;
    var ans2 = req.body.answer2;

    DButilsAzure.execQuery(`SELECT * FROM Questions Where username= '` + name + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "The username not exists" });
                return;
            }

            if (ans1 == result[0].answer1 && ans2 == result[0].answer2) {
                isverified = true;
                next();
            }
            else {
                res.status(400).send({ err: "incorrect answer" });
                return;
            }

        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "The username not exists" });
        });


});
router.post('/restorePassword', (req, res)=> {

    if (isverified == true) {
        DButilsAzure.execQuery(`SELECT * FROM users Where username= '` + req.body.username + `'`)
            .then(function (result) {
                const pass = {
                    password: result[0].password,
                };
                res.status(201).send(pass);
                isverified=false;

            })
            .catch(function (err) {
                console.log(err);
                res.status(400).send({ err: "The username not exists" });
                isverified=false;
            });

    }


});

router.get('/getQuestions/:username',(req, res )=> {

    var name = req.params.username;

    DButilsAzure.execQuery(`SELECT * FROM Questions Where username= '` + name + `'`)
        .then(function (result) {
            if(result==""){
                res.status(400).send({err:"The username not exists"});
                return;
            }
            const questions= {
                question1: result[0].question1,
                question2:result[0].question2,

            };
            res.status(201).send(questions)


        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({err:"The username not exists"});
        });
});


var userinterests = [];
var POIS = [];
router.get("/getPopularPOIByInterests", (req, res,next) => {

    const token = req.header("x-auth-token");
    if (!token) {
        res.status(401).send("Access denied. No token provided.");
    return;
        }
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var name = req.decoded.username;

    DButilsAzure.execQuery(`SELECT * FROM Interests Where username= '` + name + `'`)
        .then(function (result) {

            for (var i = 0; i < result.length; i++) {
                userinterests.push(result[i].interest);
            }
            next();


        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "The interests not exists" });
        });



});
router.use("/getPopularPOIByInterests", (req, res) => {




    proms=[];
    for(var m=0;m<userinterests.length;m++){
        proms.push(DButilsAzure.execQuery(`SELECT * FROM POIs Where category= '` + userinterests[m] + `'`));
    }
    Promise.all(proms).then(function (result) {
        for(var j=0;j<result.length;j++){
            var max = result[j][0].POIRank;
            POIS[j] = result[j][0].POIname;
            for (var k = 1; k < result[j].length; k++) {
                if (result[j][k].POIRank> max) {
                    max = result[j][k].POIRank;
                    POIS[j] = result[j][k].POIname;
                }
            }
        }
        res.status(201).send(POIS);
        userinterests=[];
        POIS=[];

    })



        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "The POI not exists" });
            userinterests=[];
            POIS=[];
        });
});


router.get("/getRecentSavedPOI", (req, res) => {
    const token = req.header("x-auth-token");
    if (!token) res.status(401).send("Access denied. No token provided.");
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var name = req.decoded.username;

    DButilsAzure.execQuery(`SELECT * FROM favorites Where username= '` + name + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "No POI saved"});
                return;
            }
                const saved =[];

		for(var j=0;j<result.length;j++){
			saved.push(result[j].POIname);

		}
                res.status(201).send(saved)
            
            


        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "POI not exists" });
        });


});

router.put("/addToFavoritePOISaved", (req, res,next) => {
    const token = req.header("x-auth-token");
    if (!token) {
        res.status(401).send("Access denied. No token provided.");
        return;
    }
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var name = req.decoded.username;
    DButilsAzure.execQuery(`SELECT * FROM users Where username= '` + name + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "There is a problem with username" });
                return;
            }

        })

    var poname = req.body.POIname;
    DButilsAzure.execQuery(`SELECT * FROM POIs Where POIname= '` + poname + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "The POI not exists" });
                return;
            }
            else { next();}
        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username or poi" });
        });


});
router.put("/addToFavoritePOISaved", (req, res) => {

    DButilsAzure.execQuery("insert into favorites(username, POIname) values('" + req.decoded.username + "','" + req.body.POIname + "')")
        .then(function (result) {
            res.status(200).json({
                message: 'sent to db',
            });
        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username or poi" });
        });


});

router.delete("/removeFromSavedFavoritePOI/:POI", (req, res,next) => {

    const token = req.header("x-auth-token");
    if (!token) res.status(401).send("Access denied. No token provided.");
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var username = req.decoded.username;
  


    var poi = req.params.POI;

    DButilsAzure.execQuery(`select * from favorites Where username= '` + username + `' And POIname='` + poi + `' `)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "username or POI not exists" });
                return;
            }
            else { next();}
        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username or poi" });
        });

});
router.use("/removeFromSavedFavoritePOI/:POI", (req, res) => {

    var username = req.decoded.username;
    var poi =  req.params.POI;

    DButilsAzure.execQuery(`Delete FROM favorites Where username= '` + username + `' And POIname='` + poi + `' `)

        .then(function (result) {
            res.status(200).json({
                message: 'removed',
            });
        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username or poi" });
        });

});


router.get("/getNumberOfSavedFavoritePOI", (req, res) => {

    const token = req.header("x-auth-token");
    if (!token) res.status(401).send("Access denied. No token provided.");
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var name = req.decoded.username;

    DButilsAzure.execQuery(`SELECT * FROM favorites Where username= '` + name + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "There is a problem with username" });
                return;
            }
            res.status(200).json({
                message: result.length,
            });


        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username " });
        });





});

router.get("/getAllSavedFavoritePOI", (req, res) => {
    const token = req.header("x-auth-token");
    if (!token) res.status(401).send("Access denied. No token provided.");
    try {
        const decoded = jwt.verify(token, secret);
        req.decoded = decoded;
    } catch (exception) {
        res.status(400).send("Invalid token.");
        return;
    }

    var name = req.decoded.username;

    DButilsAzure.execQuery(`SELECT * FROM favorites Where username= '` + name + `'`+` ORDER BY counter DESC`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "No POIs saved" });
                return;
            }

            poi = [];
            for (var i = 0; i < result.length; i++) {
                poi.push(result[i].POIname);
            }
            res.status(200).send(poi);



        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with username " });
        });

});





