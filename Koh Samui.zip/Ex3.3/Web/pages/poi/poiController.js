// poi controller
var orderedList=[];
var myWindow;
var inp;
angular.module("myApp")
.controller("poiController", function ($window,$rootScope,$scope, $http) {
    
    var img2 = document.getElementById("POI");
    var img3 = document.getElementById("star");
    $scope.Img=[];
    $scope.POIS=[];
    $scope.star=[];
    
    $scope.ranks=[];
    $scope.Category="food";

    for(var i=0;i<6;i++)
        $scope.star.push("https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png")
        
        

    $scope.update=function(){
        displayImage($scope.Category,false);
    
    }


    function displayImage(catagory,issort){
        $http.get('http://127.0.0.1:3000/POIs/getPOIByCategory/'+catagory)
        .then(function(response){            

            if(!issort){
            for(var i=1;i<=response.data.length;i++){
                loadImageS(i,response.data[i-1]);
                $scope.POIS[i]=response.data[i-1];

            }
            $scope.ranks=[];

            addrank();


        }
        else{

            $scope.ranks.sort(function(a,b){
                return a.POIRank - b.POIRank;
                }
            );
            var sortedpoi=[];
            for(var k=0;k<response.data.length;k++){
                sortedpoi[k]=$scope.ranks[k].POIname;
            }
            console.log(sortedpoi);
            for(var i=0;i<sortedpoi.length;i++){
                loadImageS(i+1,sortedpoi[i]);
                $scope.POIS[i+1]=sortedpoi[i];

            }

        }



        })
        .catch(function(err){
            $scope.error=err.data.err;
            
        })


    }


    function addrank(){
       
         proms=[];
            proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIS[1]))
            proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIS[2]))
            proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIS[3]))
            proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIS[4]))
            proms.push($http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIS[5]))
        Promise.all(proms).then(function(response){ 

            for(var i=0;i<response.length;i++){
              
                const poi_rank={
                POIname:$scope.POIS[i+1],
                POIRank:response[i].data.POIRank
                };    

            $scope.ranks.push(poi_rank);
            }
            console.log($scope.ranks);

        })
            

       
        
        .catch(function(err){
            $scope.error=err.data.err;
        })


        }




    $scope.sort=function(){
        displayImage($scope.Category,true);
    }



    $scope.find=function(){
        $scope.error="";
        $http.get('http://127.0.0.1:3000/POIs/getPOIByName/'+$scope.POIName)
        .then(function(response){    
            img2.style.visibility = 'visible'; 
            img3.style.visibility = 'visible'; 
            $scope.POIS[0]=$scope.POIName;
            loadImageS(0,$scope.POIName);
            $scope.error="";
        })
        .catch(function(err){
            $scope.error=err.data.err;
        })
       
        

    }


        function loadImageS(i,POI){
                $scope.error=""
                $http.get('http://127.0.0.1:3000/POIs/GetPictureLink/'+POI)
                .then(function(response){
                    $scope.Img[i]=response.data.Link;
                    $scope.error="";
                })  
                .catch(function (err) {
                    $scope.error=err.data.err;
            
                });
            
    }






    $scope.Cat=["food", "Shopping", "attractions", "night clubs"];
    
    $scope.addfav=function(POI1,index){
        
        if($rootScope.token==""){
            alert("You must to Login In order to add to favorite");
            return;
        }

        if($scope.star[index]=="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png"){
            
        $rootScope.removefavorite(POI1);
        $scope.star[index]="https://cdn0.iconfinder.com/data/icons/bookmarks-tags-8/24/tag_favorite_star_Add_Bookmark-512.png";
        }


        else{
            $rootScope.addtofavorite(POI1);
            $scope.star[index]="https://www.shareicon.net/download/2017/04/22/884960_star_512x512.png";
        }

    }


    $scope.opendetailes=function(POI1){

        $window.sessionStorage.setItem(1,POI1);   
        $window.open
       ('/index.html#!/POIDetailes', 
       'C-Sharpcorner', 
       'toolbar=no,scrollbars=no,resizable=no,top=100,left=500,width=600,height=400');
   
   }
   
});
