const express = require("express");
const app = express();
var DButilsAzure = require('./DButils');
const jwt = require("jsonwebtoken");
app.use(express.json());
secret = "kofkofkofi";
const router=express.Router();

module.exports = router;

router.get("/getPOIByName/:POIName", function(req, res,next) {
    req.POI={};  
    var name = req.params.POIName;
	
DButilsAzure.execQuery(`SELECT * FROM POIs Where POIname= '` + name + `'`)
        .then(function (result) {

	if(result==""){
                res.status(400).send({err:"The POI not exists"});
                return;
            }
            req.POI.POIView= result[0].numopview+1;
            req.POI.Description=result[0].POIdescription;
            req.POI.POIRank= result[0].POIRank;               
            req.POI.Date1= result[0].Date1;            
            req.POI.Date2= result[0].Date2;
             req.POI.catagory= result[0].category; 
                next();
                
            DButilsAzure.execQuery(`update POIs set numopview='` + req.POI.POIView +`'`+` where POIname='`+name+`'`)
                .then(function (result) {
	        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({err:"The POI not exists"});
        });
});

});



router.use("/getPOIByName/:POIName", function(req, res) {
DButilsAzure.execQuery(`SELECT * FROM POIReview Where POIname='` + req.params.POIName + `' ORDER BY CounterReview DESC`)
.then(function (result2) {

    if(result2.length==1){
        req.POI.POIReview1 = result2[0].Review;

        }
if(result2.length>=2){
    req.POI.POIReview1 = result2[0].Review;
    req.POI.POIReview2 = result2[1].Review;
}
    
res.status(200).send(req.POI);     


})      



})  



router.use("/GetPictureLink/:POIName", function(req, res) {

    DButilsAzure.execQuery(`SELECT * FROM Pictures Where POIname='` + req.params.POIName + `'`)
        .then(function (result) {

const Link= {
                Link: result[0].link,
              
            };
            
            res.status(201).send(Link)
        })
        .catch(function (err) {
            res.status(400).send({err:"err"});
        });

});













router.get("/getRandomPOI", (req, res) => {
    DButilsAzure.execQuery(`SELECT * FROM POIs`)
        .then(function (result) {

            var random1 = Math.floor(Math.random() * 20);
            var random2 = Math.floor(Math.random() * 20);
            while (random2 == random1) {
                random2 = Math.floor(Math.random() * 20);
            }
            var random3 = Math.floor(Math.random() * 20);

            while (random3 == random1 || random3 == random2) {
                random3 = Math.floor(Math.random() * 20);
            }

            const POIS = {
                P1: result[random1].POIname,
                P2: result[random2].POIname,
                P3: result[random3].POIname,

            };

            res.status(201).send(POIS);


        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "error" });
        });






});

router.get("/getPOIByCategory/:POICategory", (req, res) => {
    var name = req.params.POICategory;
    DButilsAzure.execQuery(`SELECT * FROM POIs Where category= '` +name + `'`)
        .then(function (result) {
            if (result == "") {
                res.status(400).send({ err: "The catagory not exists" });
                return;
            }
            var poiforcatagory=[];
            for(var m=0;m<result.length;m++){
                poiforcatagory.push(result[m].POIname);
            }

            res.status(200).send(poiforcatagory);

        })


        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "The POI not exists" });
        });

});


router.put("/addPOIReview", (req, res,next) => {

    DButilsAzure.execQuery(`SELECT * FROM POIs Where POIname= '` + req.body.POI + `'`)
        .then(function (result) {
            if(result==""){
                res.status(400).send({err:"The POI not exists"});
                return;
            }
            else {
                next();
            }


        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({err:"The POI not exists"});
        });




});
router.use("/addPOIReview", (req, res) => {
    DButilsAzure.execQuery("select max(CounterReview) from POIReview")
        .then(function (result) {
            if(result==""){
                var x=1;
            }
            else{
                var max = result[0];
                var x=max[Object.keys(max)[0]]+1;;
            }
            DButilsAzure.execQuery("insert into POIReview(POIname, Review,CounterReview) values('" + req.body.POI + "','" + req.body.POIReview+"','" + x+ "')")
                .then(function (result) {
                    res.status(200).json({
                        message: 'sent review to db',
                    });
                })
        })

        .catch(function (err) {
            console.log(err);
            res.status(400).send({ err: "There is a problem with insert review to db" });
        });



});



router.put("/addPOIRank", (req, res) => {

    if(!validnum(req.body.POIRank)){
        res.status(400).send({err:"The rank should be 1-5 integer"});
        return;
    }

    DButilsAzure.execQuery(`SELECT * FROM POIs Where POIname= '` + req.body.POI + `'`)
        .then(function (result) {
            if(result==""){
                res.status(400).send({err:"The POI not exists"});
                return;
            }
            else {

                var currentrank = result[0].POIRank;
                var counterrank= result[0].CounterRank;
                var newrank = (currentrank*counterrank +parseInt(req.body.POIRank))/(counterrank+1);
                var newcounter =  counterrank+1;



                DButilsAzure.execQuery(`update POIs set POIRank='` + newrank +  `',CounterRank='`+newcounter +`'`+` where POIname='`+req.body.POI+`'`)
                    .then(function (result) {
                        res.status(201).send({err:"updated rank"});

                    })

                    .catch(function (err) {
                        console.log(err);
                        res.status(400).send({err:"The POI not exists"});
                    });





            }



        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send({err:"The POI not exists"});
        });

});
function validnum(str) {
    if (str != "1" && str != "2" && str != "3" && str != "4" && str != "5") {
        return false;
    }
    else {
        return true;
    }
}