// about controller
angular.module("myApp")
.controller("aboutController", function ($scope) {
    self = this;
    self.pic = {
        1: {name:"pic1",  image: "http://static.asiawebdirect.com/m/phuket/portals/kosamui-com/homepage/pagePropertiesImage/koh-samui.jpg"},
        2: {name:"pic2", image: "https://cdn.thecrazytourist.com/wp-content/uploads/2018/07/ccimage-shutterstock_131758238.jpg"},
        3: {name:"pic3", image: "https://cdn.thecrazytourist.com/wp-content/uploads/2015/09/Oktoberfest-Koh-Samui-Nikki-Beach.jpg"},
        4: {name:"pic4", image: "https://cdn.thecrazytourist.com/wp-content/uploads/2018/07/ccimage-shutterstock_192572285.jpg"}
    }
});